-- Normalize text columns into proper DATE/NUMERIC/BOOLEAN types.
-- Usage:
--   psql "$DATABASE_URL" -v schema=mavryk -f migrations/001_normalize_types.sql
-- Provide your schema with -v schema=..., default falls back to "mavryk".

\if :{?schema}
\echo Using schema :schema
\else
\echo No -v schema supplied, defaulting schema to mavryk
\set schema mavryk
\endif

SET search_path TO :"schema", public;

BEGIN;

-- ---------- Helpers ----------
CREATE OR REPLACE FUNCTION safe_cast_date(v_input TEXT)
RETURNS DATE
LANGUAGE plpgsql
AS $$
DECLARE
  cleaned TEXT;
BEGIN
  cleaned := NULLIF(TRIM(v_input), '');
  IF cleaned IS NULL THEN
    RETURN NULL;
  END IF;

  IF cleaned ~ '^\d{4}-\d{2}-\d{2}' THEN
    RETURN SUBSTRING(cleaned FROM 1 FOR 10)::date;
  ELSIF cleaned ~ '^\d{2}/\d{2}/\d{4}' THEN
    RETURN TO_DATE(SUBSTRING(cleaned FROM 1 FOR 10), 'DD/MM/YYYY');
  ELSIF cleaned ~ '^\d{2}-\d{2}-\d{4}' THEN
    RETURN TO_DATE(SUBSTRING(cleaned FROM 1 FOR 10), 'DD-MM-YYYY');
  ELSIF cleaned ~ '^\d{4}/\d{2}/\d{2}' THEN
    RETURN TO_DATE(SUBSTRING(cleaned FROM 1 FOR 10), 'YYYY/MM/DD');
  ELSIF cleaned ~ '^\d{8}$' THEN
    RETURN TO_DATE(cleaned, 'YYYYMMDD');
  END IF;

  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION safe_cast_numeric(v_input TEXT)
RETURNS NUMERIC
LANGUAGE plpgsql
AS $$
DECLARE
  cleaned TEXT;
BEGIN
  cleaned := NULLIF(TRIM(v_input), '');
  IF cleaned IS NULL THEN
    RETURN NULL;
  END IF;
  IF cleaned ~ '^[-+]?\d+(\.\d+)?$' THEN
    RETURN cleaned::numeric;
  END IF;
  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION safe_cast_timestamptz(v_input TEXT)
RETURNS TIMESTAMPTZ
LANGUAGE plpgsql
AS $$
DECLARE
  cleaned TEXT;
BEGIN
  cleaned := NULLIF(TRIM(v_input), '');
  IF cleaned IS NULL THEN
    RETURN NULL;
  END IF;
  BEGIN
    RETURN cleaned::timestamptz;
  EXCEPTION
    WHEN others THEN
      RETURN safe_cast_date(cleaned)::timestamptz;
  END;
END;
$$;

-- ---------- Orders ----------
ALTER TABLE order_list
  ALTER COLUMN order_date TYPE date USING safe_cast_date(order_date::text),
  ALTER COLUMN order_expired TYPE date USING safe_cast_date(order_expired::text),
  ALTER COLUMN days TYPE integer USING NULLIF(TRIM(days::text), '')::integer,
  ALTER COLUMN cost TYPE numeric USING safe_cast_numeric(cost::text),
  ALTER COLUMN price TYPE numeric USING safe_cast_numeric(price::text),
  ALTER COLUMN refund TYPE numeric USING safe_cast_numeric(refund::text),
  ALTER COLUMN check_flag TYPE boolean USING
    CASE
      WHEN check_flag IS NULL THEN NULL
      WHEN TRIM(check_flag::text) = '' THEN NULL
      WHEN LOWER(TRIM(check_flag::text)) IN ('1','t','true','y','yes') THEN TRUE
      WHEN LOWER(TRIM(check_flag::text)) IN ('0','f','false','n','no') THEN FALSE
      ELSE NULL
    END;

ALTER TABLE order_expired
  ALTER COLUMN order_date TYPE date USING safe_cast_date(order_date::text),
  ALTER COLUMN order_expired TYPE date USING safe_cast_date(order_expired::text),
  ALTER COLUMN days TYPE integer USING NULLIF(TRIM(days::text), '')::integer,
  ALTER COLUMN cost TYPE numeric USING safe_cast_numeric(cost::text),
  ALTER COLUMN price TYPE numeric USING safe_cast_numeric(price::text),
  ALTER COLUMN refund TYPE numeric USING safe_cast_numeric(refund::text),
  ALTER COLUMN check_flag TYPE boolean USING
    CASE
      WHEN check_flag IS NULL THEN NULL
      WHEN TRIM(check_flag::text) = '' THEN NULL
      WHEN LOWER(TRIM(check_flag::text)) IN ('1','t','true','y','yes') THEN TRUE
      WHEN LOWER(TRIM(check_flag::text)) IN ('0','f','false','n','no') THEN FALSE
      ELSE NULL
    END;

ALTER TABLE order_canceled
  ALTER COLUMN order_date TYPE date USING safe_cast_date(order_date::text),
  ALTER COLUMN order_expired TYPE date USING safe_cast_date(order_expired::text),
  ALTER COLUMN createdate TYPE date USING safe_cast_date(createdate::text),
  ALTER COLUMN days TYPE integer USING NULLIF(TRIM(days::text), '')::integer,
  ALTER COLUMN cost TYPE numeric USING safe_cast_numeric(cost::text),
  ALTER COLUMN price TYPE numeric USING safe_cast_numeric(price::text),
  ALTER COLUMN refund TYPE numeric USING safe_cast_numeric(refund::text),
  ALTER COLUMN check_flag TYPE boolean USING
    CASE
      WHEN check_flag IS NULL THEN NULL
      WHEN TRIM(check_flag::text) = '' THEN NULL
      WHEN LOWER(TRIM(check_flag::text)) IN ('1','t','true','y','yes') THEN TRUE
      WHEN LOWER(TRIM(check_flag::text)) IN ('0','f','false','n','no') THEN FALSE
      ELSE NULL
    END;

-- ---------- Payment receipts / refunds ----------
ALTER TABLE payment_receipt
  ALTER COLUMN ngay_thanh_toan TYPE date USING safe_cast_date(ngay_thanh_toan::text),
  ALTER COLUMN so_tien TYPE numeric USING safe_cast_numeric(so_tien::text);

ALTER TABLE refund
  ALTER COLUMN ngay_thanh_toan TYPE date USING safe_cast_date(ngay_thanh_toan::text),
  ALTER COLUMN so_tien TYPE numeric USING safe_cast_numeric(so_tien::text);

-- ---------- Product price / descriptions ----------
ALTER TABLE product_price
  ALTER COLUMN pct_ctv TYPE numeric USING safe_cast_numeric(pct_ctv::text),
  ALTER COLUMN pct_khach TYPE numeric USING safe_cast_numeric(pct_khach::text),
  ALTER COLUMN pct_promo TYPE numeric USING safe_cast_numeric(pct_promo::text),
  ALTER COLUMN is_active TYPE boolean USING
    CASE
      WHEN is_active IS NULL THEN TRUE
      WHEN LOWER(TRIM(is_active::text)) IN ('0','false','f','no','n') THEN FALSE
      ELSE TRUE
    END,
  ALTER COLUMN "update" TYPE date USING safe_cast_date("update"::text);

ALTER TABLE product_desc
  ALTER COLUMN product_id TYPE integer USING NULLIF(TRIM(product_id::text), '')::integer;

-- ---------- Supply / pricing ----------
ALTER TABLE supply
  ALTER COLUMN active_supply TYPE boolean USING
    CASE
      WHEN active_supply IS NULL THEN TRUE
      WHEN LOWER(TRIM(active_supply::text)) IN ('0','false','f','no','n','inactive') THEN FALSE
      ELSE TRUE
    END;

ALTER TABLE supply_price
  ALTER COLUMN product_id TYPE integer USING NULLIF(TRIM(product_id::text), '')::integer,
  ALTER COLUMN source_id TYPE integer USING NULLIF(TRIM(source_id::text), '')::integer,
  ALTER COLUMN price TYPE numeric USING safe_cast_numeric(price::text);

ALTER TABLE payment_supply
  ALTER COLUMN source_id TYPE integer USING NULLIF(TRIM(source_id::text), '')::integer,
  ALTER COLUMN import TYPE numeric USING safe_cast_numeric(import::text),
  ALTER COLUMN paid TYPE numeric USING safe_cast_numeric(paid::text);

-- ---------- Packages / accounts ----------
ALTER TABLE package_product
  ALTER COLUMN expired TYPE date USING safe_cast_date(expired::text),
  ALTER COLUMN "Import" TYPE numeric USING safe_cast_numeric("Import"::text),
  ALTER COLUMN slot TYPE numeric USING safe_cast_numeric(slot::text);

ALTER TABLE account_storage
  ALTER COLUMN storage TYPE numeric USING safe_cast_numeric(storage::text);

-- ---------- Warehouse / users ----------
ALTER TABLE warehouse
  ALTER COLUMN created_at TYPE timestamptz USING safe_cast_timestamptz(created_at::text);

ALTER TABLE users
  ALTER COLUMN createdat TYPE timestamptz USING safe_cast_timestamptz(createdat::text);

COMMIT;
