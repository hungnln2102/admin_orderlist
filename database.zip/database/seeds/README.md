# Seeds

Add optional seed SQL files here (e.g., `sample_data.sql`). Files in this folder will be copied into `/docker-entrypoint-initdb.d/seeds/` by the database Dockerfile and executed in alphabetical order by Postgres on first init.
