"""Static validator for the Antigravity 17-agent package.
This checks package structure/frontmatter/content markers; it does not run Antigravity.
"""
from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parent
AGENTS = ROOT / '.agents' / 'agents'
EXPECTED = {
 'chief-orchestrator','requirement-analyst','system-architect','ux-ui-designer','frontend-engineer',
 'backend-engineer','database-data-engineer','security-specialist','performance-reliability-engineer',
 'qa-test-engineer','debugger-incident-investigator','code-reviewer','devops-infrastructure-engineer',
 'documentation-specialist','final-auditor','project-context-keeper','devils-advocate-challenger'
}
REQUIRED_TEAM = {'00-charter.md','01-workflow.md','02-task-lifecycle.md','03-delegation-matrix.md','04-reporting.md','05-handoff.md','06-quality-and-independence.md','07-project-context.md','08-antigravity-compatibility.md'}
KNOWN_TOOLS = {'view_file','grep_search','replace_file_content','run_command','invoke_subagent'}

def main():
    errors=[]; warnings=[]
    found={p.stem for p in AGENTS.glob('*.md')}
    if found != EXPECTED: errors.append(f'agent set mismatch: missing={sorted(EXPECTED-found)} extra={sorted(found-EXPECTED)}')
    for p in sorted(AGENTS.glob('*.md')):
        s=p.read_text(encoding='utf-8')
        if not s.startswith('---\n'): errors.append(f'{p.name}: missing YAML start'); continue
        m=re.match(r'^---\n(.*?)\n---\n',s,re.S)
        if not m: errors.append(f'{p.name}: malformed frontmatter'); continue
        fm=m.group(1)
        for key in ('name:','description:','tools:','mainAgent:','subagent:','model:','commandExecutionPolicy:'):
            if key not in fm: errors.append(f'{p.name}: missing {key[:-1]}')
        for tool in re.findall(r'^  - (\S+)$', fm, re.M):
            if tool not in KNOWN_TOOLS: errors.append(f'{p.name}: unknown tool {tool}')
        for marker in ('## Responsibilities','## Boundaries','## Inputs','## Outputs','## Workflow','## Escalation','## Quality checklist'):
            if marker not in s: errors.append(f'{p.name}: missing section {marker}')
    team={p.name for p in (ROOT/'.agents'/'team').glob('*.md')}
    errors += [f'missing team document {x}' for x in sorted(REQUIRED_TEAM-team)]
    if len(found)!=17: errors.append('expected exactly 17 agents')
    chief=(AGENTS/'chief-orchestrator.md').read_text(encoding='utf-8')
    if 'subagent: false' not in chief or 'mainAgent: true' not in chief: errors.append('chief flags incorrect')
    for p in AGENTS.glob('*.md'):
        if p.name!='chief-orchestrator.md' and 'subagent: true' not in p.read_text(encoding='utf-8'): errors.append(f'{p.name}: not invokable subagent')
    for name in ('README.md','ARCHITECTURE.md'):
        if not (ROOT/name).exists(): errors.append(f'missing {name}')
    if warnings: print('\n'.join('WARNING: '+x for x in warnings))
    if errors:
        print('\n'.join('ERROR: '+x for x in errors)); return 1
    print(f'PASS: {len(found)} agents, {len(team)} team docs, templates/examples present')
    return 0
if __name__ == '__main__': sys.exit(main())
