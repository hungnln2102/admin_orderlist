# Output và reporting format

## Mọi agent report phải có

| Field | Nội dung |
| --- | --- |
| task_id / report_id | IDs ổn định, ví dụ T-001 / T-001-QA-C03 |
| agent_name / agent_session_id | Role slug và instance/conversation ID thực tế |
| report_type | REQUIREMENT, DESIGN, IMPLEMENTATION, VERIFICATION, REVIEW, AUDIT, CONTEXT, DOCUMENTATION, RCA hoặc CHALLENGE |
| verdict / validity | PASS/FAIL/BLOCKED/NEEDS_INPUT; CURRENT/STALE |
| input_versions / candidate_id | AC/design/context refs và immutable snapshot |
| contributor_history | Artifact đã góp nội dung; independence declaration cho verifier |
| scope / summary | Việc được giao và outcome cụ thể |
| artifacts / changed_paths | Refs đến file/diff/report; ai sở hữu |
| evidence / checks | Check ID, AC IDs, command/method, environment, result, evidence ref |
| findings / risks / unknowns | ID, severity, impact, owner, status |
| recommended_transition / next_handoff | Đề xuất state, recipient, input refs và remaining conditions |

Dùng `.agents/templates/agent-report.md` làm cấu trúc chuẩn; thêm bảng chuyên biệt cho role, không bỏ field nền. Orchestrator persist reports vào `.agents/team-work/tasks/<task-id>/reports/`. Agent read-only trả report text để Orchestrator lưu; engineer chỉ ghi report trực tiếp khi allowed paths cho phép. Không cần mọi agent có filesystem write chỉ để bàn giao.

## Evidence contract

- Evidence có ref thực tồn tại, description, candidate/source revision, environment, method/command và timestamp/timezone khi có yếu tố thời gian.
- Với command: nêu command thật đã chạy, exit/result và raw output ref đã redacted. Không dùng “tests pass” khi chưa chạy hoặc chỉ nhìn output cũ.
- Với code review: cite exact file/symbol/line trên revision; giải thích đường gây lỗi và điều kiện xảy ra. Không cần command cho mọi finding.
- Với UX/runtime: screenshot/video/browser observation có build/viewport/steps; đọc code không thay quan sát UI.
- Với benchmark: workload/data size, environment, warm-up/sample count, baseline/candidate, metrics và noise/limits. Tránh so kết quả khác điều kiện.
- `NOT_RUN` có reason + impact + next action. `N/A` có rationale và người xác nhận theo required-gate matrix; không dùng N/A để né check cần thiết.
- Evidence ở ngoài repo phải là ref người nhận truy cập được. Không gửi chỉ đường dẫn workspace riêng đã bị xóa; export/copy evidence trước cleanup.

## Finding format

`finding_id, severity, title, observed/expected, scope/location, candidate_id, evidence_refs, impact, reproduction, proposed_remedy, owner, status, resolution_revision, retest_refs`.

Status: `OPEN | FIXING | READY_FOR_RETEST | CLOSED | WAIVED | REJECTED_WITH_REASON`. Severity và waiver theo chất lượng. `CLOSED` cần retest hoặc independent resolution evidence; writer không tự đóng bằng lời nói “đã fix”.

## Báo tiến độ

Gửi khi có milestone, quyết định, blocker hoặc evidence mới; tần suất theo session/product đang dùng, không giả định tool timer. Mẫu ngắn: task/state + điều đã xác minh + uncertainty/blocker + next action. Orchestrator tổng hợp cho người dùng bằng tiếng Việt, giữ tên/path chính xác.

## Báo cáo cuối

Outcome; artifact links; behavior changed; AC/check summary; audit verdict và candidate; unresolved/residual risks; docs/context update; release status; next action nếu có. Không kể toàn bộ lịch sử tool và không tuyên bố production-ready chỉ vì unit tests xanh.

Nếu scope là package/prompt, phân biệt **static validated** với **runtime tested**. Nếu scope là application, phân biệt **implemented**, **verified**, **staged**, **released**. Template final-report chứa các trường này để người dùng nhìn được giới hạn thực tế.
