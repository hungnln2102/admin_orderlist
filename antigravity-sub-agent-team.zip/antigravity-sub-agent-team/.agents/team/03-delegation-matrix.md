# Delegation matrix

## Core chain

Mọi task có Orchestrator, Requirement Analyst và Context Keeper ở Discovery; independent Code Reviewer và Final Auditor ở Verification/Closure. QA bắt buộc cho behavior/logic/runtime changes; với docs/static work, QA có thể thực hiện link/example/static checks hoặc N/A được chốt từ đầu. Architect dùng design note ngắn cho task nhỏ, design đầy đủ cho boundary/contract change.

**Chú ý:** owner triển khai, advisor thiết kế và verifier là chức năng khác nhau. Một specialist đã viết artifact không ký duyệt chính artifact đó; chọn session độc lập không tham gia authoring hoặc dùng verifier có năng lực khác với contributor history rõ.

## Bảng routing theo loại công việc

| Trigger/task | Discovery & Design | Implementation owner | Required verification ngoài core | Conditions/notes |
| --- | --- | --- | --- | --- |
| Feature có UI + API | Analyst, Architect, UX | Frontend + Backend | QA; UX implementation review | Data nếu schema/query đổi; Security nếu quyền/data boundary đổi |
| UI/form/responsive | Analyst, UX; Architect nếu state/contract đổi | Frontend | QA behavior/accessibility checks; UX review | Screenshot/runtime evidence nếu có; không claim visual QA từ code |
| API/business logic | Analyst, Architect | Backend | QA integration/negative cases | Security cho auth/authz/input trust change; Data cho transaction/schema |
| Schema/backfill/query | Architect, Data, DevOps; Analyst xác nhận integrity rules | Data; Backend cho consumer | QA + independent migration/data review | HIGH nếu destructive/production-impact; restore evidence hoặc blocker |
| Auth/authz/session/tenant | Analyst, Architect, Security, Challenger | Backend; Frontend cho UX; Data khi schema | QA + independent Security verifier | HIGH; permission matrix + direct API negative tests |
| Latency/throughput/resource | Performance + Debugger; Architect nếu đổi cơ chế | Backend/Frontend/Data theo bottleneck | QA regression + Performance before/after | Đo baseline/workload; DevOps nếu infrastructure/capacity |
| Bug tái hiện rõ | Debugger + Analyst; Architect design note | Engineer sở hữu module | QA reproduce/retest | Security/Data/Performance nếu failure thuộc miền đó |
| Incident/service unavailable | Debugger, Performance, DevOps; Orchestrator điều phối | Relevant owner; DevOps nếu operation được phép | Health/regression + QA + specialists theo cause | Containment không vượt quyền; RCA + incident timeline |
| CI/CD/environment/IaC | DevOps + Architect nếu topology đổi | DevOps | Reviewer infra + QA smoke/checks | Security nếu secret/network/IAM; Performance nếu availability/capacity |
| External integration/jobs/queue | Analyst, Architect, Backend, DevOps | Backend; DevOps cho config | QA contract/failure/retry tests | Security cho external trust; Performance cho backpressure |
| Docs-only/setup guide | Analyst scope; Documentation; Context | Documentation | Independent docs Reviewer; link/example checks | QA runtime conditional; không tạo code/tests vô ích |
| Architecture/refactor cross-module | Architect + Challenger; Analyst impact | Engineers theo ownership | QA regression; affected specialists | API compatibility + staged integration; không scope creep |
| Data/privacy/lifecycle | Analyst, Data, Security, Architect | Data + Backend | QA + independent Security/Data review | Retention/deletion policies truy nguồn; sensitive data redacted |

## Vai trò và cách ghép thường dùng

| Vai trò | Gọi khi | Artifact chính | Handoff chính |
| --- | --- | --- | --- |
| Chief Orchestrator | Mọi request | Task/gates/final report | Toàn bộ team qua tickets |
| Requirement Analyst | Mục tiêu/AC/rule cần xác định | Requirement + AC trace | Architect, UX, QA |
| System Architect | Contract/boundary hoặc design note cho fix | Design + ADR/contracts | Implementation owners |
| UX/UI Designer | Flow/UI/accessibility | Flow + state matrix | Frontend; QA |
| Frontend Engineer | Client behavior/UI | Patch + author checks | QA/Reviewer |
| Backend Engineer | Server logic/API/jobs | Patch + author checks | QA/Reviewer |
| Database/Data Engineer | Schema/query/migration/integrity | Data design/patch/runbook | Backend, DevOps, QA |
| Security Specialist | Identity/rights/trust/secrets | Threat model + security report | Backend; independent verifier |
| Performance/Reliability Engineer | Perf/availability goal | Baseline/profile/benchmark | Engineer; perf verifier |
| QA/Test Engineer | AC validation/regression | Tests + verification report | Reviewer + Auditor |
| Debugger/Incident Investigator | Unknown root cause/repeat failure | Repro/RCA | Relevant engineer + QA |
| Code Reviewer | Mọi final diff/artifact | Review + findings | Engineer/Auditor |
| DevOps/Infrastructure Engineer | CI/infra/release/environment | Config/CI/runbook | QA/Auditor; rollout owner |
| Documentation Specialist | User/API/setup/operations docs | Docs + checked examples | Reviewer/Auditor |
| Final Auditor | Completion gate | Independent audit verdict | Orchestrator |
| Project Context Keeper | Intake, decisions, closure | Context pack/decision log | Orchestrator + all recipients |
| Devil's Advocate/Challenger | Assumption/high-risk/irreversible design | Objections/counterexamples | Analyst/Architect/decision owner |

## Quy tắc dispatch

1. Gắn task_type, risk, touched surfaces và known unknowns.
2. Chọn core + specialists từ trigger; ghi required/advisory/N/A trước implementation.
3. Tạo DAG và contracts; triển khai song song chỉ khi paths disjoint và dependency inputs đã sẵn sàng.
4. Mỗi ticket chỉ định implementer/advisor/verifier, output format, exact inputs, allowed paths và recipient. Không giao “xem toàn bộ dự án và cải thiện mọi thứ”.
5. Chọn independent session cho QA/Reviewer/Auditor; một session không vừa viết vừa ký. Tác giả Security design phải có security verifier khác cho design đó.
6. Khi cần thêm expertise do evidence mới, cập nhật matrix/task ticket và báo scope delta; không gọi specialists vô hạn.

Mẫu nhóm song song: Analyst + Context đọc baseline; sau contract, Frontend + Backend ở paths khác; trên frozen candidate, QA + Reviewer + Security có thể đọc/test độc lập; Auditor chỉ bắt đầu sau reports/gates đầy đủ.
