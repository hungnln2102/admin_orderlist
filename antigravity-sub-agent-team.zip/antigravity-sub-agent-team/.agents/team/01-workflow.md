# Team workflow — 5 phases

## Sơ đồ

```mermaid
flowchart LR
    D[Discovery] --> T[Technical Design]
    T --> I[Implementation]
    I --> V[Verification]
    V --> C[Closure]
    V -->|Lỗi code| I
    V -->|Lỗi contract| T
    V -->|Sai yêu cầu| D
    C -->|Audit fail| V
```

Phase là nhóm công việc; state là tiến độ của task. Trạng thái agent đang running/idle/killed trong Antigravity không phải trạng thái task của package.

## Phase 1 — Discovery

**States:** NEW → ANALYZING. **Lead:** Orchestrator; **owners:** Requirement Analyst + Context Keeper. **Conditional:** Debugger cho bug, Performance cho vấn đề latency, Security cho quyền/dữ liệu, Challenger cho giả định lớn.

**Input:** yêu cầu gốc, repository/context baseline, constraints và quyền hiện có.

**Công việc:** đọc hiện trạng; mục tiêu/scope/non-goals; actor/business rule; AC có IDs; impact/dependency; risk; known unknowns; baseline đo cần thiết. Bug phải có expected/actual và repro hoặc kế hoạch thu evidence. Performance phải có workload/environment và ngưỡng được chốt trước benchmark acceptance.

**Artifacts:** task spec, context pack, requirement/assumption register, risk/required-gate matrix, initial delegation plan.

**Exit gate:** AC có cách kiểm tra; câu hỏi chặn design được giải quyết; write scope và verifier dự kiến rõ. Orchestrator đối chiếu ý định người dùng, không tự duyệt nội dung mình đã đóng góp; dùng độc lập QA/Challenger/owner khi có conflict.

## Phase 2 — Technical Design

**States:** ANALYZING → DESIGNED → READY_FOR_IMPLEMENTATION. **Owner:** System Architect. **Conditional:** UX, Data, Security, Performance, DevOps, Challenger; QA bắt đầu test planning.

**Công việc:** boundary/data flow; API/schema/error/auth contracts; UX state matrix; migration/rollback; observability; implementation slices và integration order. Bug nhỏ vẫn có design note ngắn về cause/fix/regression, không bắt viết ADR dài.

**Artifacts:** design + ADR khi cần, versioned contracts, ownership/dependency map, test plan, rollout outline.

**Exit gate:** contract đủ cụ thể; design verifier độc lập đã xử lý blocker; risks/assumptions có owner; inputs cho engineer đầy đủ; QA biết cách kiểm tra. DESIGNED chỉ nghĩa có bản thiết kế; READY_FOR_IMPLEMENTATION nghĩa bản đó đã qua gate.

## Phase 3 — Implementation

**States:** IMPLEMENTING → READY_FOR_TEST. **Owners:** Frontend/Backend/Data/DevOps theo scope; Documentation chuẩn bị docs theo source; Orchestrator tích hợp.

**Công việc:** mỗi engineer ACK ticket, implement trong paths được giao, chạy author checks phù hợp, báo diff/evidence và dependency. Thay contract phải gửi change request. Tích hợp tuần tự từ baseline xác định; giải quyết conflict với owner thay vì chọn patch tùy ý.

**Artifacts:** patches/commits, implementation reports, candidate snapshot, environment/setup notes, test/docs changes, contributor ledger.

**Exit gate:** candidate tích hợp tồn tại; author checks cần thiết có kết quả; không pending implementation blocker; QA inputs usable; allowed path ownership được tôn trọng. Author checks PASS chưa phải task acceptance.

## Phase 4 — Verification

**States:** TESTING → REVIEW → AUDIT. **Owners:** QA, Code Reviewer, specialist verifiers; Final Auditor là gate tổng.

**Công việc:** QA kiểm AC/negative/integration/regression; Reviewer đọc diff và context; Security/Performance/UX/Data/DevOps thực hiện checks theo risk. Có thể chạy đọc/review song song trên cùng frozen candidate; state REVIEW chỉ bắt đầu chính thức sau QA gate đạt. Không ai sửa production code trong phiên verifier.

**Artifacts:** verification report, review/specialist reports, findings/resolutions, gate register, independent audit report.

**Exit gate:** tất cả required gates PASS hoặc N/A hợp lệ từ gate matrix; optional gaps được ghi; blocker/required NOT_RUN đã giải quyết; evidence cùng candidate; no self-approval. Không chuyển audit bằng report tổng hợp thiếu evidence refs.

**Failure loop:** classify root cause rồi route về Discovery/Design/Implementation; environment blockers giữ state với execution_status BLOCKED. Mọi revision đổi phải đánh giá evidence invalidation. Xem lifecycle để không bỏ qua retest.

## Phase 5 — Closure

**States:** AUDIT → DONE sau audit PASS và closure checks. **Owners:** Orchestrator + Documentation + Context Keeper; verifier độc lập cho artifact docs/context.

**Công việc:** chốt user-facing artifacts, docs, decision/context delta; đối chiếu audit candidate; ghi residual risks và release status. Final Auditor kiểm toàn bộ final snapshot trước DONE.

**Exit gate:** AC đạt, evidence đúng final revision, audit PASS, docs/context đã review, delivery rõ và không blocker. Nếu user yêu cầu deploy thì DONE chỉ sau deploy authorized + post-deploy checks yêu cầu; nếu scope chỉ build/prepare thì báo prepared, chưa phát hành. Không mặc định deploy để gọi task complete.

Nếu docs/context thay đổi sau audit, tạo revision và re-audit phần bị tác động trước DONE. Nếu phát hiện lỗi sau DONE, tạo linked follow-up task NEW; giữ audit/history cũ thay vì sửa lại lịch sử hoàn tất.
