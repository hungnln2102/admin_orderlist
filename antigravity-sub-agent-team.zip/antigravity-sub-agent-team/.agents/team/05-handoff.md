# Handoff protocol

## Routing

Specialist A → report/handoff proposal → Orchestrator → ticket/input pack → Specialist B → ACK. Orchestrator có thể cho B đọc artifact của A trực tiếp bằng refs; không cần copy toàn bộ chat. Peer không tự dispatch hoặc mở task mới. Cách tổ chức này là policy của package, không khẳng định Antigravity cấm peer messaging.

## Packet bắt buộc

- handoff_id, task_id, sender/recipient role + session IDs, purpose và requested action.
- current state; AC/design/context versions; base/candidate ID và immutable revision/manifest.
- objective, scope/non-goals, allowed write paths, forbidden paths và action authorization.
- artifact/evidence refs người nhận truy cập được; delta so với input cũ; dependency/contract versions.
- open findings/risks/unknowns, reproduction/setup và decisions đang chờ.
- expected outputs, required verification, verifier identity/independence và stop/escalation conditions.
- ACK record + next owner; dùng `.agents/templates/handoff.md`.

## Sequence

1. **Prepare:** sender hoàn thiện output và check refs, redaction, revision; không gửi report thiếu artifact rồi coi đã xong.
2. **Validate/routе:** Orchestrator kiểm completeness/ownership/independence, tạo recipient ticket. Task state không đổi chỉ vì sender gửi packet.
3. **Acknowledge:** B trả ACK nếu inputs đủ/current và scope rõ; NEEDS_INPUT nếu thiếu dependency; REJECTED nếu sai role/quyền/conflict. Ghi packet version trong ACK.
4. **Execute:** B làm trên frozen input; nếu input thay đổi thì dừng nhánh phụ thuộc, báo stale và xin packet version mới. Tiếp tục phần độc lập khi hữu ích.
5. **Return:** B trả artifacts/report/proposed transition; Orchestrator kiểm và lưu. Đóng handoff khi acceptance output đã đủ, không tự chuyển task DONE.

## Shared workspace và worktree

- Mặc định dùng existing project/workspace; khi viết song song, paths disjoint và contract frozen. Orchestrator giữ write-scope table.
- Nếu cần isolated worktree và môi trường hỗ trợ, giao base revision rõ; sender trả branch/commit/diff và evidence refs. Orchestrator tích hợp tuần tự và kiểm conflicts với owner.
- Không xác nhận QA bằng local worker branch khi final candidate chưa tích hợp. Candidate mới phải được QA/Reviewer biết và ACK.
- Trước cleanup, giữ patch/artifact/evidence ở nơi dùng được; không hủy worktree làm mất file chưa bàn giao.
- Nếu không có Git, dùng immutable copy/manifest/hash cho allowed artifact set. Không ghi candidate chỉ là đường dẫn mutable.

## Conflict protocol

Hai owner cần cùng file: Orchestrator serialize hoặc đổi scope; không để agent ghi đè output của nhau. Contract disagreement: Architect đề xuất delta + impact, Analyst xác nhận business, specialist review phần rủi ro. Việc cần quyết định người dùng được Orchestrator hỏi với options/impact cụ thể.

## Ví dụ packet ngắn

```yaml
handoff_id: H-T001-03
task_id: T-001
from: backend-engineer/session-be-01
to: qa-test-engineer/session-qa-01
via: chief-orchestrator/session-lead-01
candidate_id: C03
revision_ref: tasks/T-001/candidates/C03.json
inputs: [requirements-v2, api-contract-v3, implementation-be-C03]
write_scope: [tests/project-costs/]
outputs: [verification-report, reproducible-findings]
ack: PENDING
```

Đây là schema minh họa, không phải tool call của Antigravity. `session-*` và version refs phải thay bằng giá trị thực khi dispatch.
