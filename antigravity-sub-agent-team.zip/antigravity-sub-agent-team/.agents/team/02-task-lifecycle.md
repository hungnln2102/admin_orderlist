# Task lifecycle và failure loop

## Happy path

```text
NEW → ANALYZING → DESIGNED → READY_FOR_IMPLEMENTATION → IMPLEMENTING
    → READY_FOR_TEST → TESTING → REVIEW → AUDIT → DONE
```

Orchestrator là người duy nhất ghi `state`. Mỗi transition phải có timestamp, from/to, actor/session, reason, candidate ID, input versions và evidence refs. Specialist chỉ đề xuất `recommended_transition`.

## Gate cho từng chuyển trạng thái

| From → To | Điều kiện bắt buộc | Evidence chính |
| --- | --- | --- |
| NEW → ANALYZING | Task ID, yêu cầu gốc, scope ban đầu, owner được ghi | Task spec + context refs |
| ANALYZING → DESIGNED | AC/risk/baseline đủ; design artifacts đã được tạo | Requirement + design/version + assumptions |
| DESIGNED → READY_FOR_IMPLEMENTATION | Design verifier độc lập đạt; contract, dependencies, write scope, test plan đầy đủ | Design review + specialist checks cần ở design |
| READY_FOR_IMPLEMENTATION → IMPLEMENTING | Engineer ACK inputs/version; không write conflict; quyền phù hợp | Delegation ticket + ACK + ownership map |
| IMPLEMENTING → READY_FOR_TEST | Candidate tích hợp; author checks; setup/evidence đủ | Implementation reports + candidate ID |
| READY_FOR_TEST → TESTING | QA độc lập ACK candidate; environment/fixtures sẵn sàng | QA plan + preconditions |
| TESTING → REVIEW | Required QA checks PASS hoặc N/A được chốt hợp lệ; defect blockers đã đóng | QA report + AC trace |
| REVIEW → AUDIT | Independent review + required specialist verification đạt; docs/context candidate sẵn | Review/security/performance/etc reports + findings log |
| AUDIT → DONE | Audit PASS trên final snapshot; closure đủ; execution scope hoàn thành | Audit + docs/context review + final report |

Design gate, QA gate, review gate và audit gate có người kiểm tra riêng; Orchestrator xác nhận completeness và ghi state, không thay verdict bằng ý kiến của mình.

## State và execution status

`state` chỉ dùng 10 tên ở happy path. `execution_status` dùng `ACTIVE | BLOCKED | AWAITING_USER | PAUSED | CANCELLED`. Khi thiếu environment/quyền/input, giữ `state` và đổi execution_status; không thêm BLOCKED/FAILED vào lifecycle để làm lệch contract. PAUSED/CANCELLED chỉ theo chỉ đạo người dùng hoặc hủy task được họ chấp nhận. Khi unblock, trở lại ACTIVE và kiểm input freshness.

Report verdict là `PASS | FAIL | BLOCKED | NEEDS_INPUT`. Check result là `PASS | FAIL | NOT_RUN | BLOCKED | N/A`. ACK protocol là `ACK | NEEDS_INPUT | REJECTED`. Những enum này phục vụ mục đích khác nhau, không hoán đổi.

## Failure routing

| Failure | Route chính thức | Owner sửa | Điều kiện đi tiếp |
| --- | --- | --- | --- |
| AC thiếu/sai hoặc business rule mâu thuẫn | State đang làm → ANALYZING | Analyst + người quyết định yêu cầu | AC version mới; thiết kế/checks liên quan xem lại |
| Contract/architecture/migration design sai | State đang làm → ANALYZING → DESIGNED | Architect + specialist | Design mới, independent design gate, ticket mới |
| Implement/test/review/audit phát hiện product bug | TESTING/REVIEW/AUDIT → IMPLEMENTING | Engineer theo root cause | Fix → READY_FOR_TEST → TESTING → REVIEW → AUDIT |
| Design review không đạt | DESIGNED → ANALYZING → DESIGNED | Architect/UX/Data/etc | Objection resolution + independent review |
| Environment/fixture/tool unavailable | Giữ state; execution_status BLOCKED | DevOps/owner input | Preconditions phục hồi, kiểm revision rồi chạy lại |
| Missing/invalid evidence lúc AUDIT | Giữ AUDIT/BLOCKED hoặc lùi TESTING/REVIEW theo loại | QA/Reviewer/specialist | Thu evidence cần thiết, audit lại |
| Docs/context không khớp candidate | Giữ AUDIT/BLOCKED | Documentation/Context Keeper | Cập nhật, review độc lập, new snapshot + re-audit |
| Security/performance failure | Route IMPLEMENTING hoặc ANALYZING theo nguyên nhân | Relevant engineer + specialist tư vấn | Independent security/perf retest trên candidate mới |

Không nhảy IMPLEMENTING → REVIEW/AUDIT sau fix. Khi rework chỉ đổi docs/tests/config, vẫn theo các gate tương ứng; tests không liên quan có thể giữ theo invalidation rule có lý do, không phải skip âm thầm.

## Rework protocol

1. Tạo finding ID, expected/actual, severity, evidence, affected revision, proposed owner và target state.
2. Orchestrator classify failure; ghi transition hoặc blocker; mở rework ticket với acceptance cho fix.
3. Nếu cùng root cause thất bại hai vòng, giao Debugger thu RCA trước vòng sửa tiếp; không lặp cùng patch mà không evidence mới.
4. Tạo candidate mới. Đánh giá invalidation cho mỗi gate; stale verdict không được tính PASS.
5. Retest finding và regression bị tác động; independent Reviewer xem delta; Final Auditor kiểm snapshot cuối.

## Revision và evidence invalidation

- `candidate_id` là immutable snapshot label, ví dụ `C03`; ghi base commit, candidate commit nếu có, manifest/diff digest cho uncommitted hoặc non-Git files. Label tự nó không đủ chứng minh nội dung.
- Candidate bao gồm production code, tests/config/docs và context artifacts thuộc task. Repository worktree branch có tên không thay immutable revision.
- Code/contract/schema/config dependency thay đổi: invalidate các checks liên quan và audit verdict. QA/Reviewer tự xác nhận scope invalidation, Orchestrator không tự giả định.
- Nếu chỉ docs/context đổi: runtime checks có thể giữ khi verifier ghi lý do unchanged runtime dependencies; doc/context review và audit vẫn phải chạy lại trên final snapshot.
- Report cũ vẫn giữ lịch sử với `validity: STALE` và `superseded_by`. Report mới có thể dẫn lại check cũ chỉ khi verifier attests nội dung/environment liên quan không đổi, ghi source revision, impact review và rationale.
- AC đổi: cập nhật traceability và required-check matrix, invalidate design/tests bị tác động; không viết lại expected result lặng lẽ.

Task con có lifecycle riêng. Task cha không DONE khi task con PASS nhưng integration/parent AC chưa đạt. Dependency DAG phải không vòng; có vòng thì Architect/Orchestrator tách contract hoặc sequence rõ.
