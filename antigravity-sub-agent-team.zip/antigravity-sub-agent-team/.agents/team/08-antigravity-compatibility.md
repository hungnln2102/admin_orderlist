# Antigravity compatibility và giới hạn kiểm tra

Đối chiếu tài liệu chính thức ngày **06/10/2026**; nguồn có thể thay đổi sau ngày này.

- [Custom subagents](https://www.antigravity.google/docs/subagents/): định dạng Markdown/YAML, workspace discovery, frontmatter và tên tools.
- [Introducing custom agents](https://www.antigravity.google/blog/introducing-custom-agents): cách chọn custom agent chính trên Antigravity 2.0/CLI.
- [Agents command](https://www.antigravity.google/docs/cli/commands/agents/): khám phá/chọn agent qua `/agents` trong CLI.

## Profile được cung cấp

Files trong `.agents/agents/` dùng `name`, `description`, `tools`, `mainAgent`, `subagent`, `model: inherit`, `commandExecutionPolicy`. Chief là main agent; 16 specialist cho phép subagent. Không thêm key tự chế như `role`, `temperature`, `memory`, `color` vào frontmatter.

Danh sách tools chỉ dùng tên có trong tài liệu: `view_file`, `grep_search`, `replace_file_content`, `run_command`; Chief thêm `invoke_subagent`. Chức năng/availability vẫn phải đối chiếu bản cài thực tế. Không cấu hình MCP/skills/plugin không tồn tại.

Read-only design roles không có tool ghi/chạy command và đặt policy `off`. Engineer/QA/docs/context có tools ghi theo nhiệm vụ; verifier có `run_command` để checks và bị cấm sửa đối tượng review bằng prompt. `sandbox` không bảo đảm mọi lệnh đều read-only; cần permissions/CI riêng nếu muốn enforcement kỹ thuật.

## Giới hạn

Package nhắm custom agents trên **Antigravity 2.0 và CLI** theo tài liệu trên. Không xác nhận runtime cho mọi bản IDE hoặc bản cũ. Static validator kiểm tra cấu trúc/schema profile nội bộ, không gọi Antigravity parser, không kiểm tool availability/account quota và không thực thi workflow ứng dụng.

Task lifecycle, gate register, dependency graph và role routing là quy ước của team, không phải state machine/automation built-in được package cài sẵn. Chief phải thực thi bằng tools sẵn có và records; không có daemon, deployment script hay scheduler ẩn.

## Smoke check trong môi trường của bạn

1. Copy `.agents/` vào repository root sau khi merge conflicts với agents/instructions có sẵn; không ghi đè file đã tùy chỉnh.
2. Reopen session/agent selection; CLI dùng `/agents`. Xác nhận thấy `chief-orchestrator`; specialists có thể không xuất hiện như main-selectable vì `mainAgent: false`.
3. Chọn Chief rồi giao task read-only nhỏ: đọc README và hỏi Requirement Analyst + Context Keeper trả một report có task/revision/source refs.
4. Kiểm tra Chief gọi đúng specialist, nhận ACK/report và không sửa file ngoài ticket.
5. Nếu unknown tool/discovery error: so tên tools/schema với tài liệu/bản cài, điều chỉnh profile tương ứng rồi chạy lại. Đừng thêm tùy ý tên tool chưa được xác nhận. Không kết luận toàn bộ workflow đã chạy chỉ vì file được discover.

Không cần cài Python để Antigravity đọc agent files. Python chỉ phục vụ static validator tùy chọn của package. README hướng dẫn khởi động bằng prompt và các templates không yêu cầu lệnh Antigravity giả định.
