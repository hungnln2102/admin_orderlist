# Quality gates và chống self-approval

## Độc lập theo artifact

Contributor là session/cá thể đã viết hoặc góp nội dung thực chất vào artifact, gồm production code, spec, design, tests, docs, context và infra. Verifier không được thuộc contributor set của artifact đang ký duyệt. Cùng role nhưng phiên độc lập đọc source/candidate và không authoring có thể verify; đổi tên role trong cùng phiên thì không.

| Artifact | Author thường gặp | Verifier độc lập |
| --- | --- | --- |
| Requirement/AC | Analyst | Orchestrator nếu không coauthor; nếu coauthor dùng QA/Challenger/decision owner độc lập |
| Technical design/ADR | Architect + advisors | Challenger hoặc Reviewer đủ năng lực; chuyên gia độc lập cho miền HIGH |
| UX spec | UX | Analyst/Reviewer không góp spec; user decision cho yêu cầu UX chủ quan nếu cần |
| Frontend/Backend code | Engineer | QA + Code Reviewer; Security/Performance theo trigger |
| Schema/migration | Data | Reviewer có năng lực data + QA/staging evidence; Data verifier riêng khi HIGH |
| Test artifacts | QA hoặc engineer | Code Reviewer; không coi green tests là review chất lượng tests |
| Infra/CI | DevOps | Independent Reviewer + smoke/check verifier; Security khi IAM/secrets |
| Docs | Documentation | Reviewer hoặc expert owner không coauthor |
| Context/decision summary | Context Keeper | Orchestrator nếu không coauthor; nếu có dùng Reviewer/independent source check |
| Final candidate và gate chain | Nhiều authors | Final Auditor không góp artifact đang audit |

Orchestrator ghi `contributors` và `verifiers` cho từng artifact, không chỉ theo task. Nếu Orchestrator implement code để cứu task, phải disclose; vẫn điều phối/ghi state nhưng không ký review/acceptance phần đã viết. Auditor trả verdict, Orchestrator chỉ ghi transition khi điều kiện đủ.

## Gate register

Mỗi gate: `gate_id, requirement_basis, required|conditional|advisory, owner, artifact_scope, verifier_session, independence, candidate_id, result, evidence_refs, validity, waiver_id`.

Required matrix được xác định từ Discovery và cập nhật có lý do khi scope đổi. N/A chỉ hợp lệ nếu trigger thật sự không áp dụng và verifier xác nhận; không dùng N/A để biến required check thành optional sau khi fail.

## Severity và blocker

| Severity | Ý nghĩa | Gate effect |
| --- | --- | --- |
| CRITICAL | Data loss, exploitable high-impact boundary, production outage lớn có căn cứ | Chặn DONE/release; thông báo Orchestrator ngay |
| HIGH | Sai core AC, permission/integrity bug hoặc regression nghiêm trọng | Chặn gate liên quan và DONE |
| MEDIUM | Lỗi có tác động hữu hình trong scope, có workaround hợp lý | Fix trước DONE nếu vi phạm AC; ngoài AC có thể xin risk decision |
| LOW | Minor usability/style/convention issue không phá AC | Ghi residual hoặc fix theo scope; không biến thành blocker tùy ý |

Severity dựa trên impact + preconditions + confidence, không dựa theo tên tool. Vi phạm AC chặn acceptance dù label severity thấp. Không hạ severity để né gate.

## Waiver/risk acceptance

- Chỉ người có quyền quyết định rủi ro (mặc định người dùng/project owner được người dùng chỉ định) chấp nhận waiver, không phải author/verifier tự miễn.
- Waiver dành cho conditional/advisory checks hoặc risk ngoài core AC đã được giải thích. Failed required gate, self-approval, thiếu evidence cho core AC, CRITICAL/HIGH trong scope không được agent tự waive.
- Record có scope, rationale, impact, evidence gaps, accepting person, authorization ref, date/expiry, mitigation/owner và follow-up. Khi chấp nhận làm giảm scope/AC, phải cập nhật requirement/design version rồi re-verify; không ghi “done” với AC cũ vẫn fail.
- Quyền/acceptance đã được người dùng cấp trong session có thể làm source; không hỏi lại cùng quyết định. Final report vẫn nêu limitation/risk.

## Definition of Ready

AC + design/contract version; risk/required checks; dependencies; allowed paths; baseline/candidate plan; owner/verifier; environment/quyền đủ cho nhánh triển khai. Không required unresolved design blocker.

## Definition of Done

- AC trace có evidence; implementation integrated; author checks đủ.
- Required QA/review/specialist gates đạt trên final candidate hoặc kế thừa evidence có verifier attestation hợp lệ.
- No OPEN blocker/required NOT_RUN; findings/residual risks/authorized waiver đầy đủ.
- Docs/context khớp source và được review; delivered artifacts dùng được.
- Final Auditor độc lập PASS; closure hoàn thành đúng execution scope. Deploy nằm ngoài scope thì status `prepared/not released`; trong scope thì cần post-deploy checks.

## Checklist chống approval giả

1. Session IDs/contributor history có thật và khác nhau?
2. Verifier có đọc artifact/evidence trực tiếp trên candidate đúng?
3. Check đã chạy hay chỉ plan/mock? Environment có đại diện cho claim?
4. Fix/revision mới đã invalidate và retest đúng phần chưa?
5. Gate result có source/evidence và scope rõ?
6. Final report có tách implemented/verified/released và nêu remaining limits?

Những rule này là instruction-level controls. Để enforcement kỹ thuật, cần cấu hình permissions, CI/checks, protected branches hoặc automation riêng theo dự án; package không tự cài những cơ chế đó.
