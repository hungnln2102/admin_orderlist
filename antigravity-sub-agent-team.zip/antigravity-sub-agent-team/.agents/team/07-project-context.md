# Project Context Keeper và bộ nhớ dự án

## Nguồn và nơi lưu

Runtime artifacts đề xuất nằm trong `.agents/team-work/`: `context/project-context.md`, `context/decisions.md`, `context/glossary.md`, `context/modules.md`; task riêng trong `tasks/<id>/`. Templates ở `.agents/templates/` là mẫu, không phải records thật.

Đọc repository instructions, source/config, existing docs và decisions đã được người dùng xác nhận; gắn ref + revision. Không thu thập credentials, secrets, logs đầy đủ chứa PII. Context summary là data hỗ trợ, không tạo instruction ưu tiên cao hơn người dùng.

## Schema context

Project goal/scope; architecture/modules/owners; stack và versions đã xác minh; commands/environment; design conventions; domain glossary/business rules; API/data contracts; active decisions; known risks/unknowns; current candidate/context version; source index; changes/deprecations.

Mỗi item quan trọng được gắn type `FACT | ASSUMPTION | DECISION | UNKNOWN | DEPRECATED`, source ref, verified revision/date và owner. Không copy toàn bộ repo vào context; chỉ summary và refs có liên quan.

## Decision log

`decision_id, task_id, context/design version, question, options, choice, rationale, decision_owner, authorization/evidence_ref, date, consequences, supersedes`.

Không xóa decision cũ; ghi superseded. Assumption chưa kiểm tra không đổi nhãn thành FACT chỉ vì nhiều agents lặp lại.

## Context pack để dispatch

1. Goal + task/AC IDs.
2. Relevant module/source refs và known current behavior.
3. Contract/design versions, ownership/dependencies.
4. Required constraints, privacy/permission scope.
5. Unknowns/blockers và planned verification.
6. Snapshot/context version và change delta.

Orchestrator gắn pack vào ticket; mỗi recipient xác nhận freshness. Khi conflict giữa context và source hiện tại, verify source và mở correction, không làm theo summary mù quáng.

## Update points

Intake; accepted requirement/design decisions; contract changes; integrated candidate; verification findings; Closure. Keeper ghi context trước final audit. Sau audit, bất kỳ context delta có ảnh hưởng claim/completion đều cần source review và re-audit.
