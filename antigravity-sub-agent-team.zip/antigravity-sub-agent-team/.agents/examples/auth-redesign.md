# Example 3 — Auth redesign: session cookie → rotating token + tenant roles

**T-303 / HIGH.** Không được làm mất session hợp lệ, cross-tenant access hoặc refresh token; rollout phải có rollback/compatibility.

## Discovery/Design
1. Analyst lập actor/tenant/role matrix, session lifecycle và AC-303-01..; Context Keeper ghi current auth implementation và migration assumptions.
2. Architect thiết kế trust boundaries, token rotation/revocation, backward compatibility, API error semantics và rollout phases.
3. Security lập threat model/abuse cases: replay, fixation, theft, downgrade, confused deputy, direct API bypass; Challenger tìm failure/rollback gaps. Data xem token/session persistence; DevOps xem secret/config/rollout; UX xem login/expiry/reauth states.
4. Required gates: independent Security + QA + Reviewer + Final Auditor; Data/DevOps required nếu persistence/config rollout đổi.

## Implementation
1. Backend làm server enforcement trước; Data migration expand-contract; Frontend xử lý expired/reauth; DevOps chỉ prepare staging/canary plan trong quyền.
2. Mỗi change tạo candidate mới; contract/permission matrix đổi thì invalidate design/test reports tương ứng.

## Verification/Closure
1. QA direct API negative tests, role/tenant matrix, rotation/revoke/replay, old-session compatibility and regression; Security retests threat cases; Reviewer checks no UI-only authorization; DevOps checks secret references/health/rollback.
2. Final Auditor kiểm no self-approval, exact candidate, migrations/backups, docs/runbook and residual risk. Không gọi released nếu chỉ staging.
