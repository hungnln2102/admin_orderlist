# Example 2 — Bug/performance: Project list p95 tăng từ 400ms lên 2.4s

**T-202 / HIGH until classified.** Expected p95 < 800ms trên workload W1; actual 2.4s sau revision R17. Không stress production khi chưa được phép.

## Discovery
1. Orchestrator + Debugger thu timeline, candidate/base, query/log/trace refs; Context Keeper ghi environment delta.
2. Performance Engineer định nghĩa W1, dataset size, warm-up, sample count, p50/p95/p99/error/resource; Analyst xác nhận metric là AC hay operational objective.
3. Debugger tạo minimal repro/hypothesis: missing index vs N+1 vs downstream timeout; không gọi correlation là root cause.

## Design/Implementation
1. Architect + Data chọn fix minimal (query/index/pagination) và rollback/lock condition. Challenger hỏi workload representative và cache invalidation.
2. Data/Backend implement C02 trong allowed paths; DevOps chuẩn bị staging plan/observability. Không apply production migration.

## Verification/Closure
1. Performance chạy before/after W1 cùng điều kiện; QA regression/error/concurrency; Reviewer kiểm transaction/pagination; Debugger xác nhận cause.
2. Nếu p95 đạt nhưng p99/error tăng, FAIL và route lại Implementation; nếu staging unavailable, giữ execution_status BLOCKED, không báo PASS.
3. Auditor kiểm benchmark evidence, QA/review, rollback/monitoring và docs runbook; báo prepared/staged/released đúng thực tế.
