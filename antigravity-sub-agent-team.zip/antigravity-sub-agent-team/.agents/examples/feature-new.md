# Example 1 — Feature mới: quản lý chi phí theo Project ID

**T-101 / MEDIUM.** Người dùng muốn tạo, sửa, xem chi phí nhân sự theo Project ID; tenant và quyền hiện có phải giữ nguyên.

## Discovery
1. Orchestrator tạo task, Context Keeper snapshot module/terms/commands.
2. Requirement Analyst xác định actor, currency/rounding/timezone, duplicate submission, empty/error/permission cases và AC-101..AC-106.
3. UX state matrix cho list/create/edit/loading/empty/error; Architect chốt API, validation, ownership và error semantics; Data kiểm tra schema/index; Security xem tenant/role boundary. QA lập trace.
4. Exit: requirement/design versions và required gates: QA, Reviewer, Final Auditor; Security/Data conditional được đánh dấu required do Project ID/tenant boundary.

## Implementation
1. Backend + Data làm paths tách nhau theo migration contract; Frontend chờ API contract nhưng có thể làm UI states; Documentation chuẩn bị source-grounded usage.
2. Mỗi ticket có H-T101-xx, candidate C01. Engineer author checks; Orchestrator tích hợp C02 sau migration/config.

## Verification/Closure
1. QA chạy AC, unauthorized direct API, duplicate/retry, validation, regression; Security kiểm cross-tenant/role; Data kiểm integrity/index; Reviewer đọc diff.
2. Finding `F-101-01` (rounding mismatch) route về Analyst/Backend; tạo C03, invalidate relevant QA/review checks, retest.
3. Final Auditor chỉ PASS khi C03 có AC trace, QA/Security/Data/Review evidence, docs/context current; report `verified: true`, `released: false` nếu user chỉ yêu cầu code package.
