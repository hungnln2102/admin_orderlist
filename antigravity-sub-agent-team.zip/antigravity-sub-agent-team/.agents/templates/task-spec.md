# Task specification

```yaml
task_id: T-000
title: "short objective"
type: feature|bug|performance|security|infra|docs|refactor
risk_tier: LOW|MEDIUM|HIGH
request: "user intent, source ref"
scope: []
non_goals: []
acceptance_criteria:
  - id: AC-001
    given: "..."
    when: "..."
    then: "..."
    verification: "test/inspection/metric"
baseline: "revision/context ref"
candidate_plan: "how snapshot is identified"
owners: {orchestrator: chief-orchestrator, implementers: [], verifiers: []}
required_gates: []
conditional_gates: []
dependencies: []
allowed_paths: []
constraints: []
assumptions: []
open_questions: []
execution_status: ACTIVE
```
