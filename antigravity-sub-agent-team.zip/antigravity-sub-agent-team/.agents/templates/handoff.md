# Handoff packet

```yaml
handoff_id: H-T000-00
task_id: T-000
from: role-slug/session-id
to: recipient-role/session-id
via: chief-orchestrator/session-id
purpose: "requested action"
state: IMPLEMENTING
execution_status: ACTIVE
candidate_id: C00
revision_ref: "immutable snapshot/manifest"
inputs: [requirements-v1, design-v1, context-v1]
write_scope: ["allowed/path/**"]
forbidden_paths: ["secrets/**", "unrelated/**"]
authorization: "ticket/user authorization reference"
artifacts: ["ref-to-artifact"]
delta: "what changed from previous packet"
open_findings: []
risks_unknowns: []
setup: "commands/fixtures/preconditions"
expected_outputs: ["report", "patch", "verification"]
required_verification: ["qa", "reviewer"]
stop_conditions: ["missing input", "contract change", "scope conflict"]
ack: PENDING # ACK | NEEDS_INPUT | REJECTED | PENDING
```

Receiver replies with ACK/NEEDS_INPUT/REJECTED, cites this packet ID and lists any input that is stale or inaccessible.
