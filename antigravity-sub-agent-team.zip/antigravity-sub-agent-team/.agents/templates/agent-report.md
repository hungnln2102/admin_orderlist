# Agent report

```yaml
task_id: T-000
report_id: T-000-ROLE-C00
agent_name: role-slug
agent_session_id: SESSION_ID
report_type: VERIFICATION
verdict: PASS # PASS | FAIL | BLOCKED | NEEDS_INPUT
validity: CURRENT # CURRENT | STALE
input_versions: [requirements-v1, design-v1, context-v1]
candidate_id: C00
contributor_history: []
independence: "No contributor conflict / describe conflict"
scope: "Exact delegated scope"
summary: "One paragraph outcome"
artifacts: []
changed_paths: []
evidence: []
findings: []
risks_or_unknowns: []
recommended_transition: "TESTING -> REVIEW"
next_handoff:
  recipient: chief-orchestrator
  action: "what recipient should do"
  conditions: []
```

Write a short **Rationale** and **Checks/evidence notes** below the YAML. Never include private chain-of-thought; include only verifiable reasons, observations, uncertainties and commands/results.
