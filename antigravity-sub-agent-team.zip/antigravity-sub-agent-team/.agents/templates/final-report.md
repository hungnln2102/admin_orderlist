# Final report

```yaml
task_id: T-000
state: DONE
execution_status: ACTIVE
final_candidate_id: C00
audited_revision: "immutable snapshot/manifest"
outcome: "what the user receives"
implemented: true
verified: true
staged: false
released: false
required_gates: PASS
audit_verdict: PASS
artifacts: []
acceptance_summary: []
residual_risks: []
waivers: []
docs_context_updated: true
next_action: "none or explicit follow-up"
```

The prose must distinguish implemented, verified, staged and released. State what was checked, what was not run, and link deliverables. A package file being created is not application runtime verification.
