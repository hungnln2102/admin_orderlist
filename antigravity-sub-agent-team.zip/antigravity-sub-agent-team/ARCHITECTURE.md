# Team architecture — condensed reference

```mermaid
flowchart TB
  U[User] --> O[Chief Orchestrator]
  O --> D[Discovery: Analyst + Context Keeper]
  D --> T[Design: Architect + UX + Challenger]
  T --> B[Build: Frontend + Backend + Data + DevOps + Docs]
  B --> V[Verify: QA + Debugger + Reviewer + Security + Performance]
  V --> A[Final Auditor]
  A --> O
  V -. failure loop .-> D
  V -. code fix .-> B
```

## Control plane

Chief owns task IDs, delegation tickets, dependency DAG, write scopes, lifecycle transitions, gate register, revisions, waivers and final report. Context Keeper maintains source-grounded facts/decisions. Every specialist returns a versioned report via Chief.

## 5 phases and 10 states

| Phase | States | Primary question |
| --- | --- | --- |
| Discovery | NEW → ANALYZING | What is the user outcome, scope, AC, risk and current behavior? |
| Technical Design | ANALYZING → DESIGNED → READY_FOR_IMPLEMENTATION | Can engineers implement without guessing contracts/failure behavior? |
| Implementation | IMPLEMENTING → READY_FOR_TEST | Is there an integrated candidate with author evidence? |
| Verification | READY_FOR_TEST → TESTING → REVIEW → AUDIT | Does the candidate meet AC and independent quality/security/performance checks? |
| Closure | AUDIT → DONE | Are final evidence, docs/context, delivery scope and residual risks accurate? |

Failure returns to the earliest phase that can fix the cause. New candidate revisions invalidate affected reports. Final Auditor never writes the artifact it audits.

## Required separation

Implementer ≠ verifier. QA validates behavior; Code Reviewer inspects diff/context; Security, Performance, Data, UX and DevOps verify their trigger domains; Final Auditor checks the entire trace. Required gates cannot be self-waived. `N/A` needs rationale and verifier confirmation.

## Three routing examples

- **Feature:** Analyst/Context → Architect/UX/Data/Security as triggers → Frontend/Backend → QA + specialist checks → Reviewer → Auditor.
- **Bug/performance:** Debugger + Performance baseline → Architect/Data remedy → engineer → same-condition benchmark + QA + Review → Auditor.
- **Auth redesign:** Analyst/Architect/Security/Challenger/Data/DevOps/UX → Backend/Data/Frontend/DevOps → negative auth tests + Security retest + Review → Auditor.

See the detailed `.agents/team/` files; this page is a navigation aid, not a replacement for the per-agent prompts.
