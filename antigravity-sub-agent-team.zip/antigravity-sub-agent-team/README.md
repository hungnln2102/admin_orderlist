# Google Antigravity — 17-Agent Engineering Team

Một package có thể commit vào workspace để Antigravity tự discover custom agents trong `.agents/agents/`. Package cung cấp 17 file agent Markdown, charter, 5-phase workflow, lifecycle, delegation matrix, report/handoff templates, quality gates và 3 workflow examples.

## Bắt đầu

1. Giữ nguyên `.agents/agents/` ở repository root. Antigravity discovery hỗ trợ `.agents/agents/<name>.md` và `.agents/agents/<name>/agent.md`.
2. Mở lại session/Agent Manager. Chọn `chief-orchestrator` làm đầu mối; specialist có `mainAgent: false` và được Chief gọi theo ticket.
3. Giao yêu cầu ngắn có mục tiêu và constraint. Chief đọc `.agents/team/` + Context Keeper, tạo task spec/AC rồi dispatch core chain.
4. Dùng `.agents/templates/` khi tạo task, handoff, report. Records thật khuyến nghị lưu trong `.agents/team-work/tasks/<task-id>/`; thư mục này không được tạo sẵn để tránh ghi trạng thái giả.
5. Xem `.agents/examples/` để thấy routing cho feature, performance/bug và auth redesign.

## 17 vai trò

| Layer | Roles |
| --- | --- |
| Coordination | Chief Orchestrator; Project Context Keeper |
| Discovery/design | Requirement Analyst; System Architect; UX/UI Designer; Devil's Advocate/Challenger |
| Build | Frontend Engineer; Backend Engineer; Database/Data Engineer; DevOps/Infrastructure Engineer; Documentation Specialist |
| Verification | QA/Test Engineer; Debugger/Incident Investigator; Code Reviewer; Security Specialist; Performance/Reliability Engineer |
| Closure | Final Auditor |

## Quy trình

`NEW → ANALYZING → DESIGNED → READY_FOR_IMPLEMENTATION → IMPLEMENTING → READY_FOR_TEST → TESTING → REVIEW → AUDIT → DONE`

Five phases: Discovery, Technical Design, Implementation, Verification, Closure. Failures route về phase đúng nguyên nhân; không nhảy qua QA/Review/Audit sau khi sửa. `execution_status` riêng (`ACTIVE`, `BLOCKED`, `AWAITING_USER`, `PAUSED`, `CANCELLED`) để task vẫn giữ lifecycle rõ khi chờ input/quyền.

## Guardrails

- One writer per path/snapshot; Orchestrator là router/state owner duy nhất.
- Không self-approval. Author checks không thay independent QA, Reviewer, Security/Performance và Final Auditor.
- Required `NOT_RUN`, stale evidence, missing input, unresolved blocker không được gọi là PASS/DONE.
- Không tự mở rộng scope, đổi contract, bỏ test, hạ severity hay gọi production action khi ticket/quyền chưa bao phủ.
- Report phân biệt implemented, verified, staged và released.

## Antigravity compatibility

Frontmatter dùng các trường documented: `name`, `description`, `tools`, `mainAgent`, `subagent`, `model`, `commandExecutionPolicy`. Profile chỉ dùng tool names tài liệu nêu (`view_file`, `grep_search`, `replace_file_content`, `run_command`, `invoke_subagent` cho Chief). Xem `.agents/team/08-antigravity-compatibility.md` để biết compatibility và giới hạn.

Package là prompt/config + templates. Nó không tự cài CI, protected branch, permission enforcement, database, deployment hay scheduler. Runtime workflow cần project hiện thực hóa các record/gate bằng tools và policy môi trường. Chạy `python validate_package.py` để kiểm static package trước khi copy/commit.

## Cấu trúc

```text
 .agents/
 ├─ agents/                 # 17 discoverable custom agents
 ├─ team/                   # charter, workflow, lifecycle, matrix, protocols, quality
 ├─ templates/              # task/report/handoff/final report
 └─ examples/               # feature, performance/bug, auth redesign
 validate_package.py        # static validation (not Antigravity runtime test)
 ARCHITECTURE.md            # condensed team architecture
 README.md
```
